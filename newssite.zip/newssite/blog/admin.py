from django.contrib import admin
from .models import Article
from .models import Comments, Messages
# Register your models here.

# admin.site.register(Article)
admin.site.register(Comments)
admin.site.register(Messages)

@admin.register(Article)
class ArticleAdmin(admin.ModelAdmin):
    class Media:
        js = ('tinyInject.js',)