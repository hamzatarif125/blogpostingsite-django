from django.shortcuts import render
from .models import Article, Comments, Messages
from django.contrib.sessions.models import Session
from django.contrib import messages
# Create your views here.





def news(request, str1):
    # if request.method == "GET":
    #     iid = request.GET['id']
    spl = "_"
    mid = str1.partition(spl)[2]
    if request.method == "POST":
        iid = request.POST['id']
        name1 = request.POST['name']
        comment1 = request.POST['comment'] 
        c = Comments(name=name1, comment=comment1, articleId=mid, approve=False)
        c.save()
        messages.success(request, "Comment submitted! Waiting for Approval")
    # if request.session.has_key{'artId'}:
    #     iid=request.sessions['artId']    
    latestArts = Article.objects.order_by('-id')[:6]
    art = Article.objects.get(id= mid)
    comms = Comments.objects.filter(articleId=mid, approve=True).order_by('-id')
    return render(request, 'single.html', {'art':art, 'latestArts':latestArts, 'comms': comms})

def category(request, name):
    # name = request.GET['name']
    arts = Article.objects.filter(category=name)
    newArts = Article.objects.order_by('-id')[:6]
    return render(request, 'category.html', {'arts': arts, 'name': name, 'newArts': newArts})   

def contact(request):
    if request.method=="POST":
        name2=request.POST['name']
        subject = request.POST['subject']
        email = request.POST['email']
        message = request.POST['description']
        m = Messages(name=name2, subject=subject, email=email, message=message)
        m.save()
        messages.success(request, "Message Received! We will contact you soon")
    return render(request, 'contact.html')     

def index(request):
    # art1 = Article()
    # art1.title = "First Article"
    # art1.date = "17-5-2020"
    # art1.category = "Entertainment"
    # art1.description = "Bla bla bla.."
    # art1.img = 'country.png'

    # art2 = Article()
    # art2.title = "First Article2"
    # art2.date = "17-5-2020"
    # art2.category = "Entertainment2"
    # art2.description = "Bla bla bla2.."
    # art2.img = 'logo.png'

    # arts=[art1, art2]

    arts = Article.objects.filter(category='Entertainment').order_by('-id')[:4]
    newsArts = Article.objects.order_by('-id')[:10]
    techArts = Article.objects.filter(category='Tech').order_by('-id')[:4]
    interArts = Article.objects.filter(category='International').order_by('-id')[:4]
    healthArts = Article.objects.filter(category='Health').order_by('-id')[:4]
    latestArts = Article.objects.order_by('-id')[:6]

    artOne = Article.objects.order_by('-id')[:1]
    artTwo = Article.objects.order_by('-id')[1:2]
    artThree = Article.objects.order_by('-id')[2:3]
    artFour = Article.objects.order_by('-id')[3:4]
    artFive = Article.objects.order_by('-id')[4:5]

    return render(request, "index.html", {'arts': arts, 'latestArts': latestArts, 'techArts': techArts, 'interArts': interArts, 'healthArts':healthArts, 'newsArts': newsArts, 'artOne': artOne,'artTwo': artTwo,'artThree': artThree,'artFour': artFour,'artFive': artFive})
