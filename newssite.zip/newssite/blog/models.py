from django.db import models

# Create your models here.

class Article(models.Model):
    title = models.CharField(max_length=200)
    img = models.ImageField(upload_to='pics')
    description = models.TextField()
    CATEGORIES_OPTS = (("Entertainment", "Entertainment"),("Tech","Tech"),("International","International"),("Health","Health"))
    category = models.CharField(max_length=100, choices=CATEGORIES_OPTS, default="International")
    date = models.DateField()
    def __str__(self):
        return self.category+": "+self.title

class Comments(models.Model):
    name = models.CharField(max_length=200)
    comment = models.TextField()
    articleId = models.IntegerField()
    approve = models.BooleanField(); 
    def __str__(self):
        return self.name+": "+self.comment

class Messages(models.Model):
    name = models.CharField(max_length=200)
    email = models.CharField(max_length=200)
    subject = models.CharField(max_length=200)
    message = models.TextField()
    def __str__(self):
        return self.email+": "+self.subject
